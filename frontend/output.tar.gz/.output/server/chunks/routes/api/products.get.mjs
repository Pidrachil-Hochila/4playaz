import { c as defineEventHandler, g as getQuery } from '../../_/nitro.mjs';
import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const products_get = defineEventHandler((event) => {
  const query = getQuery(event);
  const file = join(process.cwd(), "..", "backend", "data", "products.json");
  if (!existsSync(file)) return [];
  let products = JSON.parse(readFileSync(file, "utf-8"));
  if (query.category) {
    products = products.filter((p) => p.category === query.category);
  }
  if (query.clothingType) {
    products = products.filter((p) => p.clothingType === query.clothingType);
  }
  return products;
});

export { products_get as default };
//# sourceMappingURL=products.get.mjs.map
