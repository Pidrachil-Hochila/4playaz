import { c as defineEventHandler } from '../../_/nitro.mjs';
import { existsSync, readFileSync } from 'fs';
import { join } from 'path';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const collections_get = defineEventHandler(() => {
  const file = join(process.cwd(), "..", "backend", "data", "collections.json");
  if (!existsSync(file)) return [];
  return JSON.parse(readFileSync(file, "utf-8"));
});

export { collections_get as default };
//# sourceMappingURL=collections.get.mjs.map
