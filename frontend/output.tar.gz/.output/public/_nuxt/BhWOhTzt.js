import{J as a,D as e}from"./VimKvVqY.js";const o=a(t=>{if(t.path.startsWith("/admin")&&t.path!=="/admin/login"&&!localStorage.getItem("admin_token"))return e("/admin/login")});export{o as default};
